public class TestBank {
    
    public static void main(String[] arg) {
        
        BankAccount person1 = new BankAccount(250, 100); 

        System.out.println(person1.getCheckingBallance());
        System.out.println(person1.getSavingsBallance());
        System.out.println(BankAccount.numberOfAccounts);
        System.out.println(BankAccount.totalAmountOfMoney);
        person1.displayfunds();
    }
}
