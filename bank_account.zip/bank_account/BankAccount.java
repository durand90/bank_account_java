

public class BankAccount {
    private double checkingBallance;
    private double savingsBallance;
    public static int numberOfAccounts = 0;
    public static int totalAmountOfMoney = 0;

    public BankAccount (double checkingBallance, double savingsBallance) {
        this.checkingBallance = checkingBallance;
        this.savingsBallance = savingsBallance;
        numberOfAccounts++;
    }

    public double addToChecking(int amount) {
        return this.checkingBallance += amount;
    }

    public double addToSavings(int amount) {
        return this.savingsBallance += amount;
    }

    public double removeFromchecking(double amount) {
        if (this.checkingBallance > amount) {
            checkingBallance -= amount;
        }
        else {
            System.out.println("insufficient funds");
    }
        return this.checkingBallance;
    }

    public double removeFromSavings(double amount) {
        if (this.savingsBallance > amount) {
            savingsBallance -= amount;
        }
        else {
            System.out.println("insufficient funds");
    }
        return this.savingsBallance;
    }


    public void displayfunds() {
        System.out.println(this.getCheckingBallance());
        System.out.println(this.getSavingsBallance());
    }


    public double getCheckingBallance() {
        return checkingBallance;
    }

    public double getSavingsBallance() {
        return savingsBallance;
    }
}